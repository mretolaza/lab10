import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import pandas as pd
import itertools

def an(i):

    d_ft = pd.read_csv('temp.csv')
    d_ft = list(d_ft)
    d_ft = [float(t) for t in d_ft]
    

    d_fH = pd.read_csv('hum.csv')
    d_fH = list(d_fH)
    d_fH = [float(h) for h in d_fH]

    dfC = pd.read_csv('time.csv')
    dfC = list(dfC)

    result_.cla()
    result_1.cla()

    tempx = [a for a in range(len(d_ft))]
    hmx = [a for a in range(len(d_fH))]
    
    result_.plot(tempx, d_ft, '-o')
    
   
    result_1.plot(tempx, d_ft, '-o')
    
    result_.set_ylim(0,100)
    result_1.set_ylim(0,100)
    result_.set_ylabel('-----------Temperatura-------------')
    result_1.set_ylabel('-----------------Humedad--------------')
   

fig = plt.figure(figsize=(12,6), facecolor='#DEDEDE')
result_ = plt.subplot(121)
result_1 = plt.subplot(122)
result_.set_facecolor('#DEDEDE')
result_1.set_facecolor('#DEDEDE')


ani = FuncAnimation(plt.gcf(), an, interval=3000)
plt.show()