from random import randint, gauss
from time import sleep
import json

## Informacion y analisis obtenido de: https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/clients-all-examples.html

def truncate(n, type_='int'):
    a = n if n < 100.00 else 100.00
    a = n if n > 0.00 else 0.00
    a = a if type_ == "float" else int(a)
    return a

def produce_data():
    data_raw = {
        'Temperature' : round(truncate(gauss(50,50/3), 'float'), 2),
        'Humidity' : truncate(gauss(50,50/3)),
        'Wind direction': randint(0,7)}
    
    
    data = json.dumps(data_raw).encode('utf-8')
    return data, data_raw


def byteize(data):
    tmp_bit = int(data['Temperature']*100)
    tmp_bit = format(tmp_bit, 'b').zfill(14)
    data_bit = format(data['Wind direction'],'b').zfill(3) + format(data['Humidity'], 'b').zfill(7) + tmp_bit
    f_byte, s_byte, l_byte = chr(int(data_bit[0:8], 2)), chr(int(data_bit[8:16], 2)), chr(int(data_bit[16:], 2))
    bytestr = f_byte+s_byte+l_byte
    return(bytestr)
    

def b_decode(bytestr):
    data_bit = format(ord(bytestr[0]),'b').zfill(8) +  format(ord(bytestr[1]),'b').zfill(8) +  format(ord(bytestr[2]),'b').zfill(8)
    print(data_bit)
    wd,hum,temp = data_bit[0:3],data_bit[3:10],data_bit[10:]
    wd,hum,temp = int(wd,2),int(hum,2),int(temp,2)
    temp=float(temp/100.00)
    return(temp,hum,wd)